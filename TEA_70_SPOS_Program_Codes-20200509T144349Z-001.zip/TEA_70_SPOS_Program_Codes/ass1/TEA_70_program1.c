/*
#Assignment No.: 1
#Name :Nikhil Wagh
#TEA 70
Write a Java/ C program to create child process using fork system call. Display status of running processes (ps), use it in child process (exec) and terminate child process before completion of parent task(wait).  */

#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<wait.h>
#include<sys/types.h>
void parent()
{
	printf("\nParent created");
	printf("\nchild died");
}
int main()
{
	pid_t pid,pid1;
	int status;
	printf("\nparent executing");
	pid=fork();
	if(pid==0)
	{
		printf("\nchild created  ");
		printf("%d\n", pid);
		sleep(10);
		printf("\nchild after sleep");
		execlp("\n/bin/ls","ls",NULL);
		exit(0);
	}
	else
	{
		printf("\nParent again executing");
		printf("\n%d",pid);
		pid1=wait(&status);
		printf("\n%d",pid1);
		printf("\nchild process terminated");
		parent();
		printf("\nparent after child exit");
		printf("\nparent terminated");
		exit(0);
	}
}


/* OUTPUT
nikhil@nikhil-Veriton-Series:~/Desktop$ cd TEA-70
nikhil@nikhil-Veriton-Series:~/Desktop/TEA-70$ cd ass1
nikhil@nikhil-Veriton-Series:~/Desktop/TEA-70/ass1$ gcc TEA_70_program1.c
nikhil@nikhil-Veriton-Series:~/Desktop/TEA-70/ass1$ ./a.out

parent executing
Parent again executing
parent executing
child created  0

child after sleep3826
3826
child process terminated
Parent created
child died
parent after child exit
parent terminatednikhil@nikhil-Veriton-Series:~/Desktop/TEA-70/ass1$ ^C

